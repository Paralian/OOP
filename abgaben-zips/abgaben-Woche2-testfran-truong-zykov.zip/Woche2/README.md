# TODO

* aufgabeDrei.txt anfangen
=> KIEN: Konsolenausgabe der Aufgabe 2 eingefügt, Lösung der Aufgabe 3 eingefügt

* aufgaben überprüfen und ABGABEN?
=> KIEN: ALLES KLAR READY TO GO
