package data;

public interface Data {

    /**
     * Returns the String representation of data.
     * @return the string representation
     */
    String prettyPrint();
}
